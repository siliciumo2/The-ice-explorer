﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace The_Ice_Explorer
{
    public partial class Form2 : Form
    {
        // Строка подключения к БД
        private string connectionString = @"Data Source=siliciumo2\sqlexpress;Initial Catalog=ICY;Integrated Security=True";

        Image gameBackgroundImage;
        Image gameBackgroundImage2;

        int backgroundHeight;
        int backgroundWidth;
        int bgPositionX = 0;
        int bgPositionY = 0;
        int bg2PositionX = 0;
        int Icespeed = 12;
        int formWidth;
        int attackR = 0;
        int score = 0;
        int speed = 10;
        int attackTimer = 0;

        int[] flyingPosition = { 330, 417 };
        const int CharacterGroundY = 383;

        bool jumping = false;
        bool changeAnim = false;
        bool flyingAttack = false;
        bool gameover = false;

        Random random = new Random();
        List<Rectangle> obstacleHitBoxes = new List<Rectangle>();
        Rectangle characterHitBox;

        PrivateFontCollection newFont = new PrivateFontCollection();
        Label gameOverLabel = new Label();
        Label restartLabel = new Label();

        string nickname;

        public Form2(string nick)
        {
            InitializeComponent();
            nickname = nick;
            GameSetUp();
            Reset();
        }

        private void GameSetUp()
        {
            backgroundWidth = 912;
            backgroundHeight = 526;
            bg2PositionX = 912;
            gameBackgroundImage = Properties.Resources.BigIceland;
            gameBackgroundImage2 = Properties.Resources.BigIceland;
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            formWidth = this.ClientSize.Width;
            this.BackColor = Color.Black;

            road.Location = new Point(1, 289);
            character.Location = new Point(45, CharacterGroundY);
            character.Image = Properties.Resources.bearrun__2_;

            ice1.Location = new Point(289, 430);
            ice2.Location = new Point(427, 430);
            ice3.Location = new Point(749, 430);
            owl.Location = new Point(606, 300);

            newFont.AddFontFile("font/pixel.ttf");
            lblScore.Font = new Font(newFont.Families[0], 30, FontStyle.Bold);
            lblScore.ForeColor = Color.White;
            lblScore.BackColor = Color.Transparent;
            lblScore.Text = "Score: 0";

            // GAME OVER
            gameOverLabel.Font = new Font(newFont.Families[0], 50, FontStyle.Bold);
            gameOverLabel.ForeColor = Color.Red;
            gameOverLabel.AutoSize = true;
            gameOverLabel.BackColor = Color.Transparent;
            gameOverLabel.TextAlign = ContentAlignment.MiddleCenter;
            gameOverLabel.Visible = false;

            restartLabel.Font = new Font(newFont.Families[0], 30, FontStyle.Bold);
            restartLabel.ForeColor = Color.White;
            restartLabel.AutoSize = true;
            restartLabel.BackColor = Color.Transparent;
            restartLabel.TextAlign = ContentAlignment.MiddleCenter;
            restartLabel.Visible = false;

            gameOverLabel.Text = "GAME OVER";
            restartLabel.Text = "Tap ENTER to Restart";

            this.Controls.Add(gameOverLabel);
            this.Controls.Add(restartLabel);

            gameOverLabel.Location = new Point((this.ClientSize.Width - gameOverLabel.Width) / 2, 150);
            restartLabel.Location = new Point((this.ClientSize.Width - restartLabel.Width) / 2, 220);

            gameover = false;
            attackR = random.Next(12, 20);
        }

        private void Reset()
        {
            character.Image = Properties.Resources.bearrun__2_;
            character.Top = CharacterGroundY;

            ice1.Left = formWidth + random.Next(100, 200);
            ice2.Left = ice1.Left + random.Next(600, 800);
            ice3.Left = ice1.Left + random.Next(200, 400);
            owl.Left = formWidth + random.Next(300, 400);

            ice1.Top = 430;
            ice2.Top = 430;
            ice3.Top = 430;
            owl.Top = 300;

            GameTimer.Start();
            score = 0;
            attackTimer = 0;
            speed = 10;
            gameover = false;
            changeAnim = false;
            jumping = false;
            Icespeed = 12;

            gameOverLabel.Visible = false;
            restartLabel.Visible = false;
        }

        private void SaveRecord()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Максимальный ID из таблицы
                    int newId = 1;
                    string getMaxIdQuery = "SELECT ISNULL(MAX(ID), 0) FROM records";
                    using (SqlCommand cmd = new SqlCommand(getMaxIdQuery, connection))
                    {
                        newId = (int)cmd.ExecuteScalar() + 1;
                    }

                    // Добавление новой записи
                    string insertQuery = "INSERT INTO records (ID, Nickname, Score) VALUES (@id, @nickname, @score)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@id", newId);
                        cmd.Parameters.AddWithValue("@nickname", nickname);
                        cmd.Parameters.AddWithValue("@score", score);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении рекорда: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateHitBoxes()
        {
            characterHitBox = new Rectangle(
                character.Left + character.Width / 3,
                character.Top + (changeAnim ? 30 : 10),
                character.Width / 2,
                changeAnim ? character.Height - 30 : character.Height - 20);

            obstacleHitBoxes.Clear();
            obstacleHitBoxes.Add(new Rectangle(
                ice1.Left + (ice1.Width - (int)(ice1.Width * 0.7)) / 2,
                ice1.Top + (ice1.Height - (int)(ice1.Height * 0.7)) / 2,
                (int)(ice1.Width * 0.7),
                (int)(ice1.Height * 0.7)));

            obstacleHitBoxes.Add(new Rectangle(
                ice2.Left + (ice2.Width - (int)(ice2.Width * 0.7)) / 2,
                ice2.Top + (ice2.Height - (int)(ice2.Height * 0.7)) / 2,
                (int)(ice2.Width * 0.7),
                (int)(ice2.Height * 0.7)));

            obstacleHitBoxes.Add(new Rectangle(
                ice3.Left + (ice3.Width - (int)(ice3.Width * 0.7)) / 2,
                ice3.Top + (ice3.Height - (int)(ice3.Height * 0.7)) / 2,
                (int)(ice3.Width * 0.7),
                (int)(ice3.Height * 0.7)));

            obstacleHitBoxes.Add(new Rectangle(
                owl.Left + (owl.Width - (int)(owl.Width * 0.7)) / 2,
                owl.Top + (owl.Height - (int)(owl.Height * 0.7)) / 2,
                (int)(owl.Width * 0.7),
                (int)(owl.Height * 0.7)));
        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space && !jumping && !changeAnim)
            {
                jumping = true;
                character.Image = Properties.Resources.Bearjump;
                speed = -16;
            }

            if (e.KeyCode == Keys.S && !jumping && !changeAnim)
            {
                character.Image = Properties.Resources.Bearsit2png;
                changeAnim = true;
            }
        }

        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S && !gameover)
            {
                character.Image = Properties.Resources.bearrun__2_;
                changeAnim = false;
            }

            if (e.KeyCode == Keys.Enter && gameover)
            {
                Reset();
            }
        }

        private void FormPaintEvent(object sender, PaintEventArgs e)
        {
            Graphics Canvas = e.Graphics;
            Canvas.DrawImage(gameBackgroundImage, bgPositionX, bgPositionY, backgroundWidth, backgroundHeight);
            Canvas.DrawImage(gameBackgroundImage2, bg2PositionX, bgPositionY, backgroundWidth, backgroundHeight);
            Canvas.SmoothingMode = SmoothingMode.AntiAlias;
            Canvas.InterpolationMode = InterpolationMode.HighQualityBicubic;
        }

        private void MoveBackground()
        {
            bgPositionX -= 2;
            bg2PositionX -= 2;

            if (bgPositionX < -backgroundWidth)
                bgPositionX = bg2PositionX + backgroundWidth;

            if (bg2PositionX < -backgroundWidth)
                bg2PositionX = bgPositionX + backgroundWidth;
        }

        private void MoveObstacles()
        {
            ice1.Left -= Icespeed;
            ice2.Left -= Icespeed;
            ice3.Left -= Icespeed;

            if (flyingAttack)
            {
                owl.Left -= Icespeed;
            }
            else
            {
                owl.Left = formWidth + random.Next(300, 400);
                owl.Top = flyingPosition[random.Next(flyingPosition.Length)];
            }

            if (ice1.Left < -100)
            {
                ice1.Left = ice2.Left + ice2.Width + formWidth + random.Next(100, 300);
                attackTimer += 1;
                score += 1;
            }

            if (ice2.Left < -100)
            {
                ice2.Left = ice1.Left + ice1.Width + formWidth + random.Next(100, 300);
                attackTimer += 1;
                score += 1;
            }

            if (ice3.Left < -100)
            {
                ice3.Left = formWidth + random.Next(300, 400);
                ice3.Top = 430;
                attackTimer -= 1;
                score += 1;
            }

            if (owl.Left < -100 && flyingAttack)
            {
                owl.Left = formWidth + random.Next(300, 400);
                owl.Top = flyingPosition[random.Next(flyingPosition.Length)];
                flyingAttack = false;
                attackR = random.Next(12, 20);
            }
        }

        private void GameTimerEvent(object sender, EventArgs e)
        {
            MoveBackground();
            this.Invalidate();
            MoveObstacles();
            UpdateHitBoxes();

            lblScore.Text = "Score: " + score;

            if (jumping)
            {
                speed += 2;
                character.Top += speed;

                if (character.Top >= CharacterGroundY)
                {
                    character.Top = CharacterGroundY;
                    jumping = false;
                    speed = 10;
                    character.Image = Properties.Resources.bearrun__2_;
                }
            }

            foreach (var obstacleHitBox in obstacleHitBoxes)
            {
                if (characterHitBox.IntersectsWith(obstacleHitBox))
                {
                    GameTimer.Stop();
                    character.Image = Properties.Resources.bearrun__2_;
                    gameover = true;
                    character.Top = CharacterGroundY;

                    gameOverLabel.Visible = true;
                    restartLabel.Visible = true;

                    // Сохранение рекорда при проигрыше
                    SaveRecord();
                    return;
                }
            }

            if (attackTimer >= attackR && !flyingAttack)
            {
                flyingAttack = true;
                attackTimer = 0;
            }
        }

        private void road_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void character_Click(object sender, EventArgs e) { }
        private void owl_Click(object sender, EventArgs e) { }
    }
}