﻿namespace The_Ice_Explorer
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            lblScore = new Label();
            road = new PictureBox();
            character = new PictureBox();
            ice1 = new PictureBox();
            ice2 = new PictureBox();
            ice3 = new PictureBox();
            owl = new PictureBox();
            GameTimer = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)road).BeginInit();
            ((System.ComponentModel.ISupportInitialize)character).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ice1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ice2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ice3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)owl).BeginInit();
            SuspendLayout();
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Location = new Point(13, 9);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(38, 15);
            lblScore.TabIndex = 0;
            lblScore.Text = "label1";
            lblScore.Click += label1_Click;
            // 
            // road
            // 
            road.BackColor = Color.Transparent;
            road.BackgroundImage = (Image)resources.GetObject("road.BackgroundImage");
            road.Location = new Point(1, 289);
            road.Name = "road";
            road.Size = new Size(895, 202);
            road.TabIndex = 1;
            road.TabStop = false;
            road.Click += road_Click;
            // 
            // character
            // 
            character.BackColor = Color.Transparent;
            character.BackgroundImage = Properties.Resources.bearrun__2_;
            character.Location = new Point(45, 383);
            character.Name = "character";
            character.Size = new Size(68, 92);
            character.TabIndex = 2;
            character.TabStop = false;
            character.Click += character_Click;
            // 
            // ice1
            // 
            ice1.BackColor = Color.Transparent;
            ice1.BackgroundImage = (Image)resources.GetObject("ice1.BackgroundImage");
            ice1.Location = new Point(209, 430);
            ice1.Name = "ice1";
            ice1.Size = new Size(65, 45);
            ice1.SizeMode = PictureBoxSizeMode.AutoSize;
            ice1.TabIndex = 3;
            ice1.TabStop = false;
            ice1.Tag = "obstacle";
            // 
            // ice2
            // 
            ice2.BackColor = Color.Transparent;
            ice2.BackgroundImage = (Image)resources.GetObject("ice2.BackgroundImage");
            ice2.Location = new Point(749, 430);
            ice2.Name = "ice2";
            ice2.Size = new Size(65, 45);
            ice2.SizeMode = PictureBoxSizeMode.AutoSize;
            ice2.TabIndex = 4;
            ice2.TabStop = false;
            ice2.Tag = "obstacle";
            // 
            // ice3
            // 
            ice3.BackColor = Color.Transparent;
            ice3.BackgroundImage = (Image)resources.GetObject("ice3.BackgroundImage");
            ice3.Location = new Point(427, 430);
            ice3.Name = "ice3";
            ice3.Size = new Size(79, 45);
            ice3.SizeMode = PictureBoxSizeMode.AutoSize;
            ice3.TabIndex = 5;
            ice3.TabStop = false;
            ice3.Tag = "obstacle";
            // 
            // owl
            // 
            owl.BackColor = Color.Transparent;
            owl.BackgroundImage = Properties.Resources.polarowl;
            owl.Location = new Point(606, 330);
            owl.Name = "owl";
            owl.Size = new Size(70, 58);
            owl.TabIndex = 6;
            owl.TabStop = false;
            owl.Tag = "obstacle";
            owl.Click += owl_Click;
            // 
            // GameTimer
            // 
            GameTimer.Tick += GameTimerEvent;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.BigIceland;
            ClientSize = new Size(896, 487);
            Controls.Add(owl);
            Controls.Add(ice3);
            Controls.Add(ice2);
            Controls.Add(ice1);
            Controls.Add(character);
            Controls.Add(road);
            Controls.Add(lblScore);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MaximumSize = new Size(912, 526);
            MinimizeBox = false;
            MinimumSize = new Size(912, 526);
            Name = "Form2";
            Text = "The Ice Explorer";
            Paint += FormPaintEvent;
            KeyDown += KeyIsDown;
            KeyUp += KeyIsUp;
            ((System.ComponentModel.ISupportInitialize)road).EndInit();
            ((System.ComponentModel.ISupportInitialize)character).EndInit();
            ((System.ComponentModel.ISupportInitialize)ice1).EndInit();
            ((System.ComponentModel.ISupportInitialize)ice2).EndInit();
            ((System.ComponentModel.ISupportInitialize)ice3).EndInit();
            ((System.ComponentModel.ISupportInitialize)owl).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblScore;
        private PictureBox road;
        private PictureBox character;
        private PictureBox ice1;
        private PictureBox ice2;
        private PictureBox ice3;
        private PictureBox owl;
        private System.Windows.Forms.Timer GameTimer;
    }
}