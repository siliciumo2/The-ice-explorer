﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Text;
using System.Data.SqlClient;

namespace The_Ice_Explorer
{
    public partial class Form3 : Form
    {
        // Строка подключения к БД
        private string connectionString = @"Data Source=siliciumo2\sqlexpress;Initial Catalog=ICY;Integrated Security=True";

        private ListView listViewRecords;
        private Label labelTitle;
        private Label gameOverLabel;
        private Label restartLabel;

        private PrivateFontCollection newFont = new PrivateFontCollection();
        private Font pixelFont;

        public Form3()
        {
            InitializeComponent();
            Load += Form3_Load;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            LoadCustomFont();
            SetupUI();
            LoadHighscores();
        }

        private void LoadCustomFont()
        {
            try
            {
                newFont.AddFontFile("font/pixel.ttf");
                pixelFont = new Font(newFont.Families[0], 16, FontStyle.Bold);
            }
            catch
            {
                MessageBox.Show("Шрифт 'pixel.ttf' не найден.");
                pixelFont = new Font("Arial", 12, FontStyle.Regular);
            }
        }

        private void SetupUI()
        {
            this.Text = "Рекорды";
            this.Size = new Size(600, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.Black;

            //Заголовок
            labelTitle = new Label
            {
                Text = "РЕКОРДЫ",
                ForeColor = Color.White,
                Dock = DockStyle.Top,
                TextAlign = ContentAlignment.MiddleCenter,
                Height = 60,
                Font = new Font(newFont.Families[0], 28, FontStyle.Bold),
                BackColor = Color.Transparent
            };
            this.Controls.Add(labelTitle);

            //ListView
            listViewRecords = new ListView
            {
                Location = new Point(95, 120),
                Size = new Size(700, 300),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.FromArgb(40, 40, 40),
                ForeColor = Color.White
            };

            if (pixelFont != null)
            {
                listViewRecords.Font = pixelFont;
            }

           
            listViewRecords.Columns.Add("Место", 100);
            listViewRecords.Columns.Add("Игрок", 200);
            listViewRecords.Columns.Add("Рекорд", 400);

            this.Controls.Add(listViewRecords);

            //Кнопка Назад
            Button btnClose = new Button
            {
                Text = "Назад",
                Location = new Point(380, 430),
                Width = 150,
                Height = 40,
                Font = pixelFont,
                ForeColor = Color.White,
                BackColor = Color.Gray
            };
            btnClose.Click += (s, args) => this.Hide();
            this.Controls.Add(btnClose);
        }

        private void LoadHighscores()
        {
            try
            {
                listViewRecords.Items.Clear();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT TOP 10 Nickname, Score FROM Records ORDER BY Score DESC";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            int rank = 1;
                            while (reader.Read())
                            {
                                ListViewItem item = new ListViewItem(rank++.ToString());
                                item.SubItems.Add(reader["Nickname"].ToString());
                                item.SubItems.Add(reader["Score"].ToString());

                                listViewRecords.Items.Add(item);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки рекордов: " + ex.Message);
            }
        }
    }
}