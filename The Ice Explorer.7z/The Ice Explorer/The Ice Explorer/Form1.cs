using System;
using System.Drawing;
using System.Drawing.Text;
using System.Windows.Forms;

namespace The_Ice_Explorer
{
    public partial class Form1 : Form
    {
        private Image backgroundImage;
        private PictureBox bearAnimationBox;
        PrivateFontCollection newFont = new PrivateFontCollection();

        public Form1()
        {
            InitializeComponent();
            SetupMenu();
        }

        private void SetupMenu()
        {
            // ��������� �����
            this.Text = "The Ice Explorer - Menu";
            this.ClientSize = new Size(800, 600);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;

            // �������� �������� �����������
            backgroundImage = Properties.Resources.BigIceland;
            this.BackgroundImage = backgroundImage;
            this.BackgroundImageLayout = ImageLayout.Stretch;

            SetupBearAnimation();

            ConfigureButtons();

            // ����������� �������
            ExitpictureBox.Click += (sender, e) => Application.Exit();

            StartpictureBox.Click += (sender, e) =>
            {
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Please enter a nickname", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string nick=textBox1.Text;
                Form2 gameForm = new Form2(nick);
                gameForm.Show();
                this.Hide();
                gameForm.FormClosed += (s, args) => this.Show();
            };

            newFont.AddFontFile("font/pixel.ttf");
            textBox1.Font = new Font(newFont.Families[0], 12, FontStyle.Bold);
        }

        private void SetupBearAnimation()
        {
            // ������� PictureBox ��� ��������
            bearAnimationBox = new PictureBox
            {
                Name = "bearAnimationBox",
                Image = Properties.Resources.bearrun2,
                SizeMode = PictureBoxSizeMode.AutoSize,
                Location = new Point(128, 164),
                BackColor = Color.Transparent
            };

            // �������������� ������ �������� ���
            if (bearAnimationBox.Image != null)
            {
                // ����� ��� ���������� ������ ��������
                ImageAnimator.Animate(bearAnimationBox.Image, (s, e) =>
                {
                    if (bearAnimationBox != null && bearAnimationBox.Image != null)
                    {
                        ImageAnimator.UpdateFrames(bearAnimationBox.Image);
                        bearAnimationBox.Invalidate();
                    }
                });
            }

            this.Controls.Add(bearAnimationBox);
            bearAnimationBox.BringToFront();
        }

        private void ConfigureButtons()
        {
            int buttonWidth = 200;
            int buttonHeight = 80;

            // ��������� StartpictureBox
            StartpictureBox.Image = Properties.Resources.IMG_20250531_154145;
            StartpictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            StartpictureBox.Size = new Size(buttonWidth, buttonHeight);
            StartpictureBox.Location = new Point(538, 234);
            StartpictureBox.BackColor = Color.Transparent;
            StartpictureBox.Cursor = Cursors.Hand;
            StartpictureBox.BringToFront();

            // ��������� RecordspictureBox
            RecordspictureBox.Image = Properties.Resources.IMG_20250531_151811;
            RecordspictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            RecordspictureBox.Size = new Size(buttonWidth, buttonHeight);
            RecordspictureBox.Location = new Point(128, 92);
            RecordspictureBox.BackColor = Color.Transparent;
            RecordspictureBox.Cursor = Cursors.Hand;
            RecordspictureBox.BringToFront();

            // ��������� ExitpictureBox
            ExitpictureBox.Image = Properties.Resources.IMG_20250531_155620;
            ExitpictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            ExitpictureBox.Size = new Size(buttonWidth, buttonHeight);
            ExitpictureBox.Location = new Point(528, 312);
            ExitpictureBox.BackColor = Color.Transparent;
            ExitpictureBox.Cursor = Cursors.Hand;
            ExitpictureBox.BringToFront();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
        }

        private void RecordspictureBox_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
        }
    }
}